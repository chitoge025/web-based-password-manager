<?php
session_start();
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT id, username, password_hash FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['last_activity'] = time();

        // 1. Generate OTP
        $otp_code = rand(100000, 999999);
        $otp_expires = date('Y-m-d H:i:s', time() + 300); // store expiry in correct datetime format

        $_SESSION['otp_code'] = $otp_code;
        $_SESSION['otp_expires'] = $otp_expires;

        // 2. Save OTP into database
        $update_stmt = $pdo->prepare("UPDATE users SET otp_code = ?, otp_expires = ? WHERE id = ?");
        $update_stmt->execute([$otp_code, $otp_expires, $user['id']]);

        // 3. Display OTP on screen for testing
        echo "<h2>Login Successful!</h2>";
        echo "<p><strong>Your OTP code is: </strong>" . $otp_code . "</p>";
        echo "<p>Redirecting you to OTP verification page in 5 seconds...</p>";

        // 4. Redirect after 5 seconds
        header("refresh:5; url=../public_html/verify-otp.php");
        exit;
    } else {
        echo "Invalid login credentials!";
    }
} else {
    header("Location: ../public_html/login.php");
    exit;
}
?>
