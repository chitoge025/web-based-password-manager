<?php
session_start();
require_once '../config/database.php'; // database connection
require_once '../config/security.php'; // encryption functions
require_once '../config/key.php'; // encryption key

// CSRF protection
if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    die("Invalid CSRF token.");
}

// Check user login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$password_id = $_POST['password_id']; // Get the password ID to delete

if (empty($password_id)) {
    die("No password ID specified.");
}

// Delete password (but make sure the user owns it)
try {
    $stmt = $pdo->prepare("DELETE FROM passwords WHERE id = ? AND user_id = ?");
    $stmt->execute([$password_id, $user_id]);

    header("Location: ../public_html/dashboard.php?deleted=1");
    exit;
} catch (PDOException $e) {
    die("Error deleting password: " . $e->getMessage());
}
?>
