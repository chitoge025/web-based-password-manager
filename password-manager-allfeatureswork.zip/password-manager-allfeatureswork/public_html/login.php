<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Password Manager</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="centered">
    <div class="login-box">
        <h2>Login</h2>
        <form action="../includes/login.php" method="POST">
            <input type="text" name="username" placeholder="Username" required><br>

            <div class="password-wrapper">
                <input type="password" id="password" name="password" placeholder="Password" required>
                <button type="button" class="toggle-password" onclick="togglePassword()">👁️</button>
            </div><br>

            <button type="submit">Login</button>
        </form>
        <p>Don't have an account? <a href="register.php">Register</a></p>
    </div>

    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
            } else {
                passwordInput.type = 'password';
            }
        }
    </script>
</body>
</html>
