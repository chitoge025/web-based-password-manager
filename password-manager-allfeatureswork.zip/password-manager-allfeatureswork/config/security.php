<?php
// config/security.php
function encryptPassword($password, $encryption_key) {
    $cipher = "AES-128-CTR"; 
    $options = 0;
    $iv = '1234567891011121'; // IV must match in both encrypt and decrypt
    $encryption = openssl_encrypt($password, $cipher, $encryption_key, $options, $iv);
    return $encryption;
}

function decryptPassword($encrypted_password, $encryption_key) {
    $cipher = "AES-128-CTR"; 
    $options = 0;
    $iv_length = openssl_cipher_iv_length($cipher);
    $iv = '1234567891011121'; // Make sure this matches the IV used when encrypting
    $decryption = openssl_decrypt($encrypted_password, $cipher, $encryption_key, $options, $iv);
    return $decryption;
}
?>
