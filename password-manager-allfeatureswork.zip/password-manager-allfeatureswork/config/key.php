<?php
$encryption_key = "YOUR-VERY-STRONG-32-CHAR-SECRET-KEY-HERE"; // One place only
?>