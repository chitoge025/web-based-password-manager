<?php
session_start();

// Auto-logout after 10 minutes
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > 600) {
    session_unset();
    session_destroy();
    header("Location: login.html"); // or login.php if you use PHP login
    exit;
}
$_SESSION['last_activity'] = time();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html"); // Redirect if not logged in
    exit;
}

// Generate CSRF token if not set
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Connect to Database
$mysqli = new mysqli("localhost", "root", "", "password_manager_db");
if ($mysqli->connect_error) {
    die("Database connection failed: " . $mysqli->connect_error);
}

// Fetch passwords for logged-in user
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM passwords WHERE user_id = ?";
$stmt = $mysqli->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$passwords = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Vault - Password Manager</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <h1>Password Vault</h1>
        <button onclick="logout()">Logout</button>
    </nav>

    <!-- ✅ Success Message -->
    <?php if (isset($_GET['success'])): ?>
        <div class="alert-success">
            Password saved successfully!
        </div>
    <?php endif; ?>

    <div class="vault">
        <button class="add-btn" onclick="openModal()">+ Add New Password</button>

        <table>
            <thead>
                <tr>
                    <th>Site</th>
                    <th>Username</th>
                    <th>Password</th>
                </tr>
            </thead>
            <tbody id="vault-entries">
                <?php if (!empty($passwords)): ?>
                    <?php foreach ($passwords as $index => $password): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($password['site_name']); ?></td>
                            <td><?php echo htmlspecialchars($password['site_username']); ?></td>
                            <td>
                                <span id="password-<?php echo $index; ?>">••••••••</span>
                                <button type="button" onclick="togglePassword('<?php echo $index; ?>', '<?php echo htmlspecialchars($password['encrypted_password']); ?>')">
                                    👁️
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3">No passwords saved yet.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Add Password Modal -->
    <div id="modal" class="modal hidden">
        <div class="modal-content">
            <h2>Add New Password</h2>
            <form action="../includes/add_password.php" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <input type="text" name="site_name" placeholder="Site Name" required><br>
                <input type="text" name="site_username" placeholder="Site Username" required><br>
                <input type="text" id="site_password" name="site_password" placeholder="Password" required>
                <button type="button" onclick="document.getElementById('site_password').value = generatePassword();">
                    Generate Secure Password
                </button><br>
                <button type="submit">Save</button>
                <button type="button" class="cancel-btn" onclick="closeModal()">Cancel</button>
            </form>
        </div>
    </div>

    <script src="dashboard.js"></script>
    <script src="password_generator.js"></script>

    <!-- 👁️ Toggle Password Script -->
    <script>
    function togglePassword(index, actualPassword) {
        const passwordSpan = document.getElementById('password-' + index);
        if (passwordSpan.innerText === '••••••••') {
            passwordSpan.innerText = actualPassword;
        } else {
            passwordSpan.innerText = '••••••••';
        }
    }
    </script>
</body>
</html>
