let timer;
function resetTimer() {
    clearTimeout(timer);
    timer = setTimeout(() => {
        window.location.href = 'logout.php';
    }, 10 * 60 * 1000); // 10 minutes
}
window.onload = resetTimer;
document.onmousemove = resetTimer;
document.onkeypress = resetTimer;