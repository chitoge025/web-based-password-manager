<?php
session_start();
require_once '../config/database.php';    // Database connection
require_once '../config/security.php';    // AES encryption and decryption functions

// --- 1. Check if user is logged in ---
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php"); // Correct: relative path to login page
    exit;
}

// --- 2. CSRF Protection ---
if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    die("CSRF token validation failed.");
}

// --- 3. Sanitize Input ---
$site_name = trim($_POST['site_name']);
$site_username = trim($_POST['site_username']);
$site_password = trim($_POST['site_password']);

// --- 4. Validate Required Fields ---
if (empty($site_name) || empty($site_username) || empty($site_password)) {
    die("All fields are required.");
}

// --- 5. Encrypt the Password securely ---
$encryption_key = 'YOUR-VERY-STRONG-32-CHAR-SECRET-KEY-HERE'; // Replace with your real secure key

$encrypted_password = encryptPassword($site_password, $encryption_key);

// --- 6. Save to Database ---
try {
    $stmt = $pdo->prepare("
        INSERT INTO passwords (user_id, site_name, site_username, encrypted_password)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([
        $_SESSION['user_id'],
        htmlspecialchars($site_name),
        htmlspecialchars($site_username),
        $encrypted_password
    ]);

    // --- 7. Redirect back to dashboard after success ---
    header("Location: ../public_html/dashboard.php?success=1"); 
    exit;

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
