<?php
session_start();

// Check if OTP is set from session
if (!isset($_SESSION['otp'])) {
    header("Location: login.php");
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $entered_otp = $_POST['otp'];

    if ($entered_otp == $_SESSION['otp']) {
        // OTP matched! Allow login and redirect to dashboard
        unset($_SESSION['otp']); // OTP used, remove it

        // Set session variable to mark user as fully logged in
        $_SESSION['logged_in'] = true;

        header("Location: dashboard.php");
        exit();
    } else {
        $error = "Invalid OTP. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verify OTP - Password Manager</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="centered">
    <div class="login-box">
        <h2>Verify OTP</h2>
        <?php if (isset($error)) echo '<p style="color: red;">'.$error.'</p>'; ?>
        <form action="verify-otp.php" method="POST">
            <input type="text" name="otp" placeholder="Enter OTP" required><br>
            <button type="submit">Verify</button>
        </form>
        <p><a href="login.php">Back to Login</a></p>
    </div>
</body>
</html>
