<?php
// Start the session
session_start();

// Include database connection
require_once '../config/database.php';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die('CSRF validation failed');
    }

    // Get and sanitize input
    $username = htmlspecialchars(trim($_POST['username']));
    $password = trim($_POST['password']);

    // Validate input
    if (empty($username) || empty($password)) {
        die('Please fill in all fields.');
    }

    // Check if username already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetch()) {
        die('Username already taken.');
    }

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Insert into database
    $stmt = $pdo->prepare("INSERT INTO users (username, password_hash) VALUES (?, ?)");
    if ($stmt->execute([$username, $hashedPassword])) {
        echo "Registration successful! <a href='../public_html/login.php'>Login here</a>";
    } else {
        echo "Something went wrong. Please try again.";
    }
} else {
    die('Invalid request.');
}
?>
