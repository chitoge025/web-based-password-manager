<?php
// config/security.php
function encryptPassword($plaintext, $key) {
    $iv = openssl_random_pseudo_bytes(16); // AES-256-CBC needs a 16 bytes IV
    $encrypted = openssl_encrypt($plaintext, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($iv . $encrypted); // Save IV + Encrypted text together
}

function decryptPassword($ciphertext, $key) {
    $ciphertext = base64_decode($ciphertext);
    $iv = substr($ciphertext, 0, 16); // First 16 bytes = IV
    $encrypted = substr($ciphertext, 16);
    return openssl_decrypt($encrypted, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
}
?>
